# cat_dog_classifier

A cat dog classifier in flutter with the help of a tensorflow lite model. 

Able to detect an image(form camera or gallery) to be cat or a dog 

## Video

https://user-images.githubusercontent.com/56160052/127228701-468c3fe5-be72-4105-be3b-89df23ff5c04.mp4



