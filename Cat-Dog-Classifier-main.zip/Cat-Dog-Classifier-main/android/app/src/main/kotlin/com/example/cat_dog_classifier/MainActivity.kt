package com.example.cat_dog_classifier

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
